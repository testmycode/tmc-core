public class StudentTest {

    // very important data

}
